# Library_management-
基于JavaWeb开发的图书管理系统
### 运行环境
数据库用的是8.0.17
Tocat 9.0
JDK1.8
